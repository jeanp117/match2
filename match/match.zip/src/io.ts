import { io } from "socket.io-client";

// "undefined" means the URL will be computed from the `window.location` object
const URL = "http://192.168.1.2:3000";

export const socket = io(URL);

type Role = "players" | "consola" | "TV";

const game = {
  start: () => {
    socket.emit("game:start");
  },

  end: () => {
    socket.emit("game:end");
  },
  onStart: (callback: () => void) => {
    socket.on("game:start", callback);
  },
  onEnd: (callback: () => void) => {
    socket.on("game:end", callback);
  },
  status: () => {
    socket.emit("game:status");
  },
  onStatus: (callback: (status: any) => void) => {
    socket.on("game:status", callback);
  },
};

const device = {
  debug: (debug: boolean) => {
    socket.emit("debug", debug);
  },
  onConnect: (joinAs: Role, callback: (connected: boolean) => void) => {
    socket.on("connect", () => {
      socket.emit("joinAs", joinAs);
      callback(true);
    });
    socket.on("disconnect", () => {
      callback(false);
    });
  },
};

const player = {
  ready: (isReady: boolean) => {
    socket.emit("players:ready", isReady);
  },
  expression: (expression: string, player: string) => {
    socket.emit("player:expression", { player, expression });
  },
  bpm: (bpm: number, player: string) => {
    socket.emit("player:bpm", { player, bpm });
  },
  details: (player: string, details: any) => {
    socket.emit("player:details", { player, details });
  },
};

const video = {
  progress: (time: number) => {
    socket.emit("video:progress", time);
  },
  onProgress: (callback: (time: number) => void) => {
    socket.on("video:progress", callback);
  },
  pause: (paused: boolean) => {
    socket.emit("video:pause", paused);
  },

  duration: (duration: number) => {
    socket.emit("video:duration", duration);
  },
};

export { game, device, player, video };
