export type Jugador = {
  nombre: string;
  email: string;
  celular: string;
  genero: string;
  image?: string;
  status?: {
    bateria: number;
    bpm: number;
    emotion: string;
  };
};
