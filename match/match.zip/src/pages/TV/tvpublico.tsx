import Lottie from "lottie-react";
import { getAnimation } from "./utils";
import { GraficaBPM, updateChart } from "./grafica";
import { useEffect, useState } from "react";
import { device, game, socket } from "../../io";
import { Jugador } from "../../types";

export const TvPublicoPage = () => {
  const [isConnected, setIsConnected] = useState(false);

  const [player1, setPlayer1] = useState<Jugador>();
  const [player2, setPlayer2] = useState<Jugador>();
  const [status, setStatus] = useState<any>();
  useEffect(() => {
    device.onConnect("TV", setIsConnected);
    game.onStatus((state: any) => {
      setStatus(state.status);
      console.log(state.status);
      setPlayer1(state.players.player1);
      setPlayer2(state.players.player2);
    });
  }, [socket]);
  return (
    <div
      className="flex flex-col h-screen w-full 
        justify-between items-stretch bg-black
    "
    >
      <div className="h-1/6 text-white">{isConnected ? "🟢" : "🔴"}</div>
      {isConnected &&
      status == "playing" &&
      player1?.status &&
      player2?.status ? (
        <>
          <div className="h-fit  p-12">
            <PlayerCard
              player={{
                name: player1.nombre,
                bpm: player1.status.bpm,
                expression: player1.status?.emotion,
              }}
            />
          </div>
          <div className="h-fit  p-12">
            <PlayerCard
              player={{
                name: player2.nombre,
                bpm: player2.status.bpm,
                expression: player2.status.emotion,
              }}
            />
          </div>
        </>
      ) : (
        <div className="h-4/6 flex justify-center items-center text-white text-4xl">
          Esperando jugadores...
        </div>
      )}
      <div className="h-1/6 bg-green-400 relative">
        <img
          src="grilla.jpg"
          alt="grilla"
          className="object-cover h-full w-full"
        />
        {/* floating in the middle of the div  */}
        <img
          src="xmslogo.svg"
          alt="logo"
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2
            w-1/4 animate-pulse
          "
        />
      </div>
    </div>
  );
};

const PlayerCard = ({
  player,
}: {
  player: {
    name: string;
    bpm: number;
    expression: string;
  };
}) => {
  const [chartData, setChartData] = useState<
    Array<{
      x: number;
      y: number;
    }>
  >([]);

  useEffect(() => {
    updateChart(player.bpm, setChartData);
  }, [player.bpm]);

  return (
    <div
      className="flex flex-row gap-4 bg-white/10 h-full   rounded-3xl overflow-hidden 
      
      backdrop-blur-sm shadow-lg
      text-white
    "
    >
      <div
        className="w-8/12 text-3xl 
        flex flex-col justify-between
        "
        //add gradient inset to smooth the edges
      >
        <div className="px-4 pt-4">
          <h1 className="font-bold text-4xl">{player.name}</h1>
          <h1>EXPre{player.expression}</h1>
        </div>
        <div
          className="rounded-lg relative
            
          "
        >
          <div
            className="absolute left-4 top-0 z-30
          backdrop-blur-md
          bg-red-700/10 rounded-lg  p-2
          "
          >
            <h1>💓{player?.bpm}</h1>
          </div>
          <GraficaBPM
            top={
              //get the highest value from the chartData on Y

              Math.max(
                ...chartData.map((d) => {
                  return d.y;
                })
              ) + 20
            }
            bottom={
              //get the lowest value from the chartData on Y

              Math.min(
                ...chartData.map((d) => {
                  return d.y;
                })
              ) - 20
            }
            data={chartData || []}
          />
        </div>
      </div>
      <div className="p-3">
        <Lottie
          style={{
            height: "15vmax",
          }}
          animationData={getAnimation(player.expression)}
          loop={true}
          autoplay={true}
        />
      </div>
    </div>
  );
};
