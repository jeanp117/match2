import { useEffect, useRef, useState } from "react";
import * as faceapi from "face-api.js";
import { device, game, player, socket, video } from "../io";
import { Select, SelectItem } from "@nextui-org/react";
const FaceRecognition: React.FC<{
  player: any;
  onExpressionChange: (expression: string) => void;
  onReady: (isReady: boolean) => void;
  index: any;
}> = ({ player, onExpressionChange, onReady, index }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [camerasAvailable, setCamerasAvailable] = useState<any[]>([]);
  const [camera, setCamera] = useState<any>(null);
  const [expression, setExpression] = useState("");
  const [readyness, setReadyness] = useState({
    modelsLoaded: false,
    cameraReady: false,
  });
  //list all cameras and be aware of new cameras being connected
  useEffect(() => {
    navigator.mediaDevices.enumerateDevices().then((devices) => {
      const cameras = devices.filter((device) => device.kind === "videoinput");
      setCamerasAvailable(cameras);
    });
    navigator.mediaDevices.addEventListener("devicechange", () => {
      navigator.mediaDevices.enumerateDevices().then((devices) => {
        const cameras = devices.filter(
          (device) => device.kind === "videoinput"
        );
        setCamerasAvailable(cameras);
      });
    });
  }, []);

  useEffect(() => {
    if (camerasAvailable.length > 0 && !camera)
      setCamera(camerasAvailable[index]);
  }, [camerasAvailable]);
  //faceapi setup to detect facial expressions
  useEffect(() => {
    const loadModels = async () => {
      //check if models are loaded before using them

      if (!faceapi.nets.tinyFaceDetector.params) {
        await faceapi.nets.tinyFaceDetector.loadFromUri("/models");
      }
      if (!faceapi.nets.faceExpressionNet.params) {
        await faceapi.nets.faceExpressionNet.loadFromUri("/models");
      }
      setReadyness({ ...readyness, modelsLoaded: true });
    };

    loadModels();
  }, []);

  useEffect(() => {
    let interval: any;
    if (camera) {
      navigator.mediaDevices
        .getUserMedia({
          video: {
            deviceId: camera.deviceId,
            advanced: [{ width: 1280, height: 720 }],
          },
        })
        .then((stream) => {
          if (videoRef.current) {
            (videoRef.current as any).srcObject = stream;
            videoRef.current.addEventListener("play", function () {
              const canvas = faceapi.createCanvasFromMedia(
                videoRef.current as any
              );
              document.body.append(canvas);

              //apply filter to canvas
              // canvas.style.filter = "brightness(2.2) contrast(1.4) saturate(0) ";
              // this.style.filter = "brightness(2.2) contrast(1.4) saturate(0)";
              const displaySize = {
                width: this.width,
                height: this.height,
              };
              faceapi.matchDimensions(canvas, displaySize);
              interval = setInterval(async () => {
                const detection = await faceapi
                  .detectSingleFace(
                    videoRef.current as any,
                    new faceapi.TinyFaceDetectorOptions({
                      inputSize: 128,
                      scoreThreshold: 0.2,
                    })
                  )
                  .withFaceExpressions();
                if (detection) {
                  const expressions = detection.expressions as any;
                  const expression = Object.keys(expressions).reduce((a, b) =>
                    expressions[a] > expressions[b] ? a : b
                  );

                  //get image from canvas in base64 format

                  setExpression(expression);
                  onExpressionChange(expression);
                }
              }, 100);

              // const intervalFoto = setInterval(() => {
              //   if (videoRef.current) {
              //     // use video to get a image
              //     const canvas = document.createElement("canvas");
              //     canvas.width = 320;
              //     canvas.height = 240;
              //     const ctx = canvas.getContext("2d");
              //     ctx?.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
              //     const data = canvas.toDataURL("image/png");
              //     socket.emit("player:camera", { player, image: data });
              //   }
              // }, 128);
              //return graceful cleanup
            });
          }
        })
        .catch((err) => {
          console.error(err);
        });
    }
    return () => {
      clearInterval(interval);
      // clearInterval(intervalFoto);
      if (videoRef.current) {
        videoRef.current.pause();
      }
    };
  }, [camera]);

  useEffect(() => {
    console.log("readyness", readyness);
    onReady(readyness.modelsLoaded && readyness.cameraReady);
  }, [readyness]);

  if (!readyness.modelsLoaded) {
    return <div>Loading models</div>;
  }

  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-xl flex flex-col w-full justify-between">
      <div className=" bg-slate-400 aspect-video relative">
        <div
          className=" aspect-square rounded-full bg-white absolute left-2 top-2 z-20 
        text-3xl
        "
        >
          {(() => {
            switch (expression) {
              case "neutral":
                return "😐";
              case "happy":
                return "😀";
              case "sad":
                return "😢";
              case "angry":
                return "😠";
              case "fearful":
                return "😨";
              case "disgusted":
                return "🤢";
              case "surprised":
                return "😲";
              default:
                return "😐";
            }
          })()}
        </div>
        {camera ? (
          <video
            src=""
            ref={videoRef}
            autoPlay
            muted
            onCanPlay={() => {
              setReadyness({ ...readyness, cameraReady: true });
            }}
            className="w-full h-auto  object-cover  "
          ></video>
        ) : (
          <div className="w-full h-full flex flex-col justify-center  items-center  object-cover bg-zinc-600">
            <svg
              className="w-24 h-24 text-gray-800 dark:text-white"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                fillRule="evenodd"
                d="M14 7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7Zm2 9.387 4.684 1.562A1 1 0 0 0 22 17V7a1 1 0 0 0-1.316-.949L16 7.613v8.774Z"
                clipRule="evenodd"
              />
            </svg>
            <h1 className="text-white">
              Conecte una cámara para poder ver la expresión facial
            </h1>
          </div>
        )}
      </div>
      <div className="p-4 ">
        {expression}

        {camerasAvailable.length > 0 && (
          <Select
            label="Seleccionar cámara"
            onChange={(e) => {
              const camera = camerasAvailable.find(
                (camera) => camera.deviceId === e.target.value
              );
              console.log("camera", camera);
              setCamera(camera);
            }}
            selectionMode="single"
            defaultSelectedKeys={[camerasAvailable[0].deviceId]}
          >
            {camerasAvailable.map((cameraAvailable) => (
              <SelectItem
                key={cameraAvailable.deviceId}
                value={cameraAvailable.deviceId}
              >
                {cameraAvailable.label}
              </SelectItem>
            ))}
          </Select>
        )}
      </div>
    </div>
  );
};

export const Players = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [videoURL, setVideoURL] = useState();
  const [playersReady, setPlayersReady] = useState({
    player1: false,
    player2: false,
  });
  useEffect(() => {
    device.onConnect("players", (isConnected) => {
      setIsConnected(isConnected);
    });
  }, []);

  useEffect(() => {
    if (videoRef.current) {
      video.duration(videoRef.current.duration);

      game.onStatus((status) => {
        console.log("status", status);
        setVideoURL(status.video.url);
      });

      game.onStart(() => {
        if (videoRef.current) {
          videoRef.current?.pause();
          videoRef.current.currentTime = 0;
          videoRef.current?.play();
        }
      });
    }
    if (playersReady.player1 && playersReady.player2) {
      player.ready(true);
    }
  }, [socket, playersReady, videoRef.current]);

  useEffect(() => {
    //each second
    const interval = setInterval(() => {
      let heartrate1 = Math.floor(Math.random() * 40) + 60;
      player.bpm(heartrate1, "player1");
      let heartrate2 = Math.floor(Math.random() * 40) + 60;
      player.bpm(heartrate2, "player2");
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative  bg-zinc-200 h-screen overflow-hidden flex flex-col justify-center items-center">
      <div className="  max-h-screen   ">
        <div className="absolute left-1 top-1 z-50 text-xs">
          {isConnected ? "🟢" : "🔴"}
        </div>
        <video
          src={videoURL}
          className="w-full h-auto object-cover  absolute top-0 left-0"
          ref={videoRef}
          onTimeUpdate={(e) => {
            if (videoRef.current) {
              video.progress(e.currentTarget.currentTime);
            }
          }}
        ></video>
        <div className="flex flex-row gap-4  justify-center absolute   ">
          {["player1", "player2"].map((jugador, index) => (
            <FaceRecognition
              key={index}
              index={index}
              player={jugador}
              onReady={(isReady) => {
                setPlayersReady((prev) => ({ ...prev, [jugador]: isReady }));
                console.log("playersReady", playersReady);
              }}
              onExpressionChange={(expression) => {
                console.log("expression", expression);
                if (!expression) return;
                player.expression(expression, jugador);
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
