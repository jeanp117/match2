import {
  Button,
  Input,
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  Select,
  SelectItem,
  Slider,
  useDisclosure,
} from "@nextui-org/react";
import { useEffect, useState } from "react";
import { socket, video, player, device, game } from "../io";

type Jugador = {
  nombre: string;
  email: string;
  celular: string;
  genero: string;
  image?: string;
  status?: StatusJuego;
};

type StatusJuego = {
  bateria: number;
  bpm: number;
  emocion: string;
};
export const ConsolaPage = () => {
  const [player1, setPlayer1] = useState<Jugador | undefined>();
  const [player2, setPlayer2] = useState<Jugador | undefined>();
  const [videoProgress, setVideoProgress] = useState(0);
  const [videoDuration, setVideoDuration] = useState(0);
  const [isConnected, setIsConnected] = useState(false);
  const [status, setStatus] = useState<
    "waiting" | "ready" | "playing" | "ended"
  >();
  const [sections, setSections] = useState<
    [
      {
        name: string;
        start: number;
        end: number;
      }
    ]
  >();

  useEffect(() => {
    device.onConnect("consola", (isConnected) => {
      setIsConnected(isConnected);
    });
    game.onStatus((status: any) => {
      console.log(status);
      setStatus(status.status);
      setPlayer1(status.players.player1);
      setPlayer2(status.players.player2);
      if (!sections)
        setSections(
          status.video.sections.map((section: any) => ({
            label: section.name,
            value: section.end / status.video.duration,
          }))
        );
      setVideoDuration(status.video.duration);
    });
    video.onProgress(setVideoProgress);
  }, [socket]);

  return (
    <div className="flex flex-row justify-center ">
      <div className="absolute left-1 top-1 z-50 text-xs">
        {isConnected ? "🟢" : "🔴"}
      </div>
      <div className="absolute left-1 top-1 z-50 text-xs">Status{status}</div>
      <div className="container ">
        <div className="flex flex-col gap-4 justify-center p-2">
          <StatusJugador
            jugador={player1}
            onEdit={(jugador) => player.details("player1", jugador)}
          />
          <StatusJugador
            jugador={player2}
            onEdit={(jugador) => player.details("player2", jugador)}
          />
        </div>
        <div className="flex flex-row p-4 bg-white shadow-lg rounded-lg">
          <Slider
            label="Avance del video"
            step={0.01}
            formatOptions={{ style: "percent" }}
            maxValue={1}
            minValue={0}
            marks={sections as any}
            value={videoProgress / videoDuration || 0}
            className="max-w-md"
          />
        </div>
        <div className=" w-full h-1/2 flex flex-col items-center justify-center relative p-4">
          <div
            className="absolute w-12 flex flex-col justify-center items-center bg-slate-300 aspect-square rounded-full left-4 top-4 text-white hover:scale-125
          
          "
          >
            🤡
          </div>
          <div
            className="absolute w-20 flex flex-col justify-center items-center bg-red-500 aspect-square rounded-full left-4 bottom-0 text-white"
            onClick={() => confirm("¿Estás seguro de parar?")}
          >
            Parar
          </div>
          <div
            className="
            
            w-52 aspect-square rounded-full shadow-md hover:scale-105 hover:shadow-lg bg bg-green-500 flex flex-col justify-center items-center text-white font-bold text-4xl
        select-none
        "
            onClick={() => {
              console.log();
              switch (status) {
                case "waiting":
                  game.start();
                  break;
                case "ready":
                  game.start();
                  break;
                case "playing":
                  video.pause(true);
                  break;
                case "ended":
                  game.start();
                  break;
              }
            }}
          >
            {status}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatusJugador: React.FC<{
  jugador: Jugador | undefined;
  onEdit: (jugador: Jugador) => void;
}> = ({ jugador, onEdit }) => {
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const [jugadorLocal, setJugadorLocal] = useState<
    Partial<Jugador> | undefined
  >(jugador);

  return (
    <>
      <Modal
        placement="bottom"
        backdrop="blur"
        isOpen={isOpen}
        onOpenChange={onOpenChange}
      >
        <ModalContent>
          <ModalHeader className="flex flex-col gap-1">
            Editar jugador
          </ModalHeader>
          <ModalBody>
            <div className="flex flex-col w-full flex-wrap md:flex-nowrap gap-4">
              <Input
                type="text"
                label="Nombre"
                placeholder="Nombre completo"
                defaultValue={jugadorLocal?.nombre}
                onValueChange={(value) => {
                  setJugadorLocal({ ...jugadorLocal, nombre: value });
                }}
              />
              <Input
                type="email"
                label="Email"
                defaultValue={jugadorLocal?.email}
                placeholder="Correo electrónico"
                onValueChange={(value) => {
                  setJugadorLocal({ ...jugadorLocal, email: value });
                }}
              />
              <Input
                type="tel"
                label="Celular"
                placeholder="Número de celular"
                defaultValue={jugadorLocal?.celular}
                onValueChange={(value) => {
                  setJugadorLocal({
                    ...jugadorLocal,
                    celular: value,
                  });
                }}
              />
              <Select
                label="Género"
                placeholder="Seleccionar"
                selectedKeys={
                  jugadorLocal?.genero ? [jugadorLocal?.genero] : undefined
                }
                selectionMode="single"
                defaultSelectedKeys={
                  jugadorLocal?.genero ? [jugadorLocal?.genero] : undefined
                }
                onChange={(e) => {
                  setJugadorLocal({
                    ...jugadorLocal,
                    genero: e.target.value,
                  });
                }}
              >
                <SelectItem value="M" key={"M"}>
                  Masculino
                </SelectItem>
                <SelectItem value="F" key={"F"}>
                  Femenino
                </SelectItem>
                <SelectItem value="O" key={"O"}>
                  Otro
                </SelectItem>
              </Select>
            </div>
          </ModalBody>
          <ModalFooter>
            <Button
              size="lg"
              fullWidth
              color="primary"
              onPress={() => {
                onEdit(jugadorLocal as Jugador);
                onOpenChange();
              }}
              isDisabled={
                !(
                  jugadorLocal?.celular &&
                  jugadorLocal?.nombre &&
                  jugadorLocal?.email &&
                  jugadorLocal?.genero
                )
              }
            >
              Guardar
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
      <div
        className="flex   flex-row  bg-white shadow-lg rounded-lg p-4 gap-4 "
        onClick={onOpen}
      >
        {jugador ? (
          <>
            <div className="aspect-square w-2/5 ">
              <img
                src={jugador.image}
                className="object-cover h-full rounded-lg"
              />
            </div>
            <div className="flex flex-col gap-2">
              <h2 className="font-bold text-xl">{jugador.nombre}</h2>
              <h2>🔋 {jugador.status?.bateria}%</h2>
              <hr />
              <h2>💓 {jugador.status?.bpm}bpm</h2>
              <h2>😃 {jugador.status?.emocion}</h2>
            </div>
          </>
        ) : (
          <>
            <Button className="pointer-events-none" fullWidth>
              Seleccionar jugador
            </Button>
          </>
        )}
      </div>
    </>
  );
};
